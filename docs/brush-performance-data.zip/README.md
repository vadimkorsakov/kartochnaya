# PR #55 benchmark
PR: https://github.com/vadimkorsakov/kartochnaya/pull/55
SHA: 29e852bcad8c1ff83c81061f47fc619e29f3100c
Base: bdb841f2b2999b8fb077ae897c4448dca1ce3d91
Reproduce using scripts/measure-brush.cjs and tests/README.md in that commit.
One pass per scenario, 360 points in 36 batches, sequential before/after.
All durations are milliseconds. Nested API measurements are inclusive.
frames.work combines event handlers and the preview callback in the same rAF;
it is not GPU/presentation time. Summary p95 uses nearest rank.
Container CPU quota: 2 vCPU. No parallel browser tests during the measurements.
